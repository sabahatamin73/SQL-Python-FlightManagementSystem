
- By default values has been added to the airline table by the .sql file.
- For loging in as a Travel Agent, use 'test' as username and '123' as password.
Note: Both things will be populated after running the database.sql file.