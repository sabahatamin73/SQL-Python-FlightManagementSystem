from PyQt6 import QtWidgets, uic,  QtGui
from PyQt6.QtCore import QDate
from PyQt6.QtWidgets import QApplication, QMainWindow, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget, QHeaderView
import sys
import pyodbc
from PyQt6.QtGui import QFont
from PyQt6 import QtWidgets, QtCore
import re
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QLabel, QLineEdit, QDateEdit, QScrollArea, QPushButton, QWidget
from PyQt6 import QtWidgets, uic, QtCore

server = 'MYLENOVO'
database = 'Final'  # Name of your Northwind database
use_windows_authentication = True  # Set to True to use Windows Authentication
username = 'your_username'  # Specify a username if not using Windows Authentication
password = 'your_password'  # Specify a password if not using Windows Authentication

if use_windows_authentication:
    connection_string = f'DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};Trusted_Connection=yes;'
else:
    connection_string = f'DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};UID={username};PWD={password}'

class OnBoarding(QtWidgets.QMainWindow):
    def __init__(self):
        super(OnBoarding, self).__init__()
        uic.loadUi('Screens/travelor/OnBoarding Screen.ui', self)
        self.Travel_agent_push_button.clicked.connect(self.show_travel_agent_login)
        self.Traveler_push_button.clicked.connect(self.show_traveler_screen)

    def show_travel_agent_login(self):
        self.travel_agent_login = TravelAgentLogin()
        self.travel_agent_login.show()

    def show_traveler_screen(self):
        self.traveler_reg= TravelerRegistration()
        self.traveler_reg.show()

class TravelerRegistration(QtWidgets.QMainWindow):
    def __init__(self):
        super(TravelerRegistration, self).__init__()
        uic.loadUi('Screens/travelor/Registration.ui', self)
        self.Register_pushButton.clicked.connect(self.register_traveler)
        self.logintraveler_pushButton.clicked.connect(self.show_traveler_login)

    def register_traveler(self):
        name = self.Name_lineEdit.text()
        username = self.Username_lineEdit.text()
        password = self.Password_lineEdit.text()
        email = self.Email_lineEdit.text()

        if not self.is_valid_username(username):
            self.show_error_message("Invalid username. It must be 5 or more characters long and contain only letters and numbers.")
            return

        if not self.is_valid_email(email):
            self.show_error_message("Invalid email address.")
            return

        connection = pyodbc.connect(connection_string)
        cursor = connection.cursor()

        try:
            cursor.execute("""
                INSERT INTO Travelor (Name, Username, Password, Email) 
                VALUES (?, ?, ?, ?)
                """,
                (name, username, password, email)) 
            connection.commit()
            connection.close()
            self.clear_fields()
            self.show_success_message()
            self.redirect_to_login()

        except pyodbc.Error as ex:
            print("Error:", ex)

    def is_valid_username(self, username):
        return re.match("^[a-zA-Z0-9]{5,}$", username) is not None

    def is_valid_email(self, email):
        return re.match(r"[^@]+@[^@]+\.[^@]+", email) is not None

    def clear_fields(self):
        self.Name_lineEdit.clear()
        self.Username_lineEdit.clear()
        self.Password_lineEdit.clear()
        self.Email_lineEdit.clear()

    def show_success_message(self):
        QtWidgets.QMessageBox.information(self, "Registration Successful", "You have been registered successfully.")

    def show_traveler_login(self):
        self.close() 
        self.traveler_login = TravelerLogin()
        self.traveler_login.show()

    def redirect_to_login(self):
        self.close()  
        self.login_screen = TravelerLogin()
        self.login_screen.show()

    def show_error_message(self, message):
        QtWidgets.QMessageBox.warning(self, "Validation Error", message)


class TravelerLogin(QtWidgets.QMainWindow):
    def __init__(self):
        super(TravelerLogin, self).__init__()
        uic.loadUi('Screens/Travelor/Login.ui', self)
        self.login_pushButton.clicked.connect(self.login)

    def login(self):
        username = self.UsernamelineEdit.text()
        password = self.PasswordlineEdit.text()

        connection = pyodbc.connect(connection_string)
        cursor = connection.cursor()

        q = "SELECT Travelor_id FROM Travelor WHERE Username = ? AND Password = ?"
        cursor.execute(q, (username, password))
        traveler = cursor.fetchone()

        if traveler:
            self.close()
            traveler_id = traveler[0]
            self.search = SearchFlights(traveler_id)
            self.search.show()
        else:
            QtWidgets.QMessageBox.warning(self, "Login Failed", "Invalid username or password. Please try again.")


class SearchFlights(QtWidgets.QMainWindow):
    def __init__(self, traveler_id):
        super(SearchFlights, self).__init__()
        uic.loadUi('Screens/travelor/Search.ui', self)
        self.traveler_id = traveler_id

        self.Search_pushButton.clicked.connect(self.search_flights)
        self.book_pushButton_3.clicked.connect(self.book_flight)
        # self.submit_button

  
    def search_flights(self):
        departure_city = self.DepartureCity_lineEdit.text()
        arrival_city = self.ArrivalCity_lineEdit.text()
        departure_date = self.DepartureDate_dateEdit.text()
        num_passengers = int(self.NumPassengers_spinBox.value())
        
        try:
            connection = pyodbc.connect(connection_string)
            cursor = connection.cursor()

            query = """
                SELECT Flight_id, Airline_id, Departure_city, Arrival_city, Departure_time, Arrival_time, available_seats, Cost, Departure_airport, Arrival_airport, Departure_date, Arrival_date
                FROM Flights 
                WHERE Departure_city = ? 
                AND Arrival_city = ? 
                AND Departure_date = ? 
                AND available_seats >= ?
            """
            cursor.execute(query, (departure_city, arrival_city, departure_date, num_passengers))
            flights = cursor.fetchall()

            self.FlightsTableWidget.clearContents()

            if flights:  # Check if flights is not empty
                self.FlightsTableWidget.setRowCount(len(flights))
                self.FlightsTableWidget.setColumnCount(len(flights[0]))  

                headers = ["FlightID", "AirlineID", "DepartureCity", "ArrivalCity", "DepartureTime", "ArrivalTime", "AvailableSeats", "Cost", "DepAirport", "ArrivalAirport", "DepartureDate", "ArrivalDate"]
                self.FlightsTableWidget.setHorizontalHeaderLabels(headers)

                for row_num, row_data in enumerate(flights):
                    for col_num, data in enumerate(row_data):
                        item = QtWidgets.QTableWidgetItem(str(data))
                        self.FlightsTableWidget.setItem(row_num, col_num, item)
            else:
                self.FlightsTableWidget.setRowCount(0)
                self.FlightsTableWidget.setColumnCount(0)
                QtWidgets.QMessageBox.information(self, "No Flights Found", "No flights match your search criteria.")

            connection.close()

        except pyodbc.Error as ex:
            print("Error:", ex)

    def book_flight(self):
        selected_row = self.FlightsTableWidget.currentRow()
        if selected_row != -1:  
            flight_id_item = self.FlightsTableWidget.item(selected_row, 0)
            if flight_id_item:
                flight_id = int(flight_id_item.text())

                try:
                    connection = pyodbc.connect(connection_string)
                    cursor = connection.cursor()

                    cursor.execute("""
                        INSERT INTO Bookings (Flight_id, Travelor_id, Booking_status) 
                        VALUES (?, ?, ?)
                    """, (flight_id, self.traveler_id, 'False'))

                    num_passengers = int(self.NumPassengers_spinBox.value())
                    if num_passengers > 0:
                        cursor.execute("SELECT @@IDENTITY AS 'Booking_id'")
                        booking_id = cursor.fetchone()[0]
                        self.close()
                        self.add_passengers = PassengerInfoDialog(num_passengers, flight_id, self.traveler_id, booking_id)
                        self.add_passengers.exec()
                    else:
                        QtWidgets.QMessageBox.warning(self, "Invalid Passenger Count",
                                                    "Please select a valid number of passengers within available seats.")
                    connection.commit()
                    connection.close()

                except pyodbc.Error as ex:
                    print("Error:", ex)
                    QtWidgets.QMessageBox.warning(self, "Booking Error", "An error occurred while booking the flight.")

        else:
            QtWidgets.QMessageBox.warning(self, "No Flight Selected", "Please select a flight to book.")


class TravelAgentLogin(QtWidgets.QMainWindow):
    def __init__(self):
        super(TravelAgentLogin, self).__init__()
        uic.loadUi('Screens/Travel Agent/Login.ui', self)
        self.Login_pushButton.clicked.connect(self.login)

    def login(self):
        # Implement login logic here
        username = self.Username_lineEdit.text()
        password = self.Password_lineEdit.text()

        # Establishing a connection to the database
        connection = pyodbc.connect(connection_string)
        cursor = connection.cursor()

        q = "SELECT * FROM TravelAgent WHERE Username = ? AND Password = ?"
        cursor.execute(q, (username, password))
        row = cursor.fetchone() #First matching row
        if row:
            self.close()
            self.on_boarding = OnBoardingTravelAgent()  
            self.on_boarding.show() 
        else:
            QtWidgets.QMessageBox.warning(self, "Login Failed", "Invalid username or password. Please try again.")

class OnBoardingTravelAgent(QtWidgets.QMainWindow):
    def __init__(self):
        super(OnBoardingTravelAgent, self).__init__()
        uic.loadUi('Screens/Travel Agent/On Boarding.ui', self)
        self.AddFlights_pushButton.clicked.connect(self.show_add_flights_screen)
        self.viewbooked_pushbutton.clicked.connect(self.view_bookings)
        self.availableflights.clicked.connect(self.available_flights)
    def show_add_flights_screen(self):
        self.add_flights_screen = AddFlightsDialog()
        self.add_flights_screen.show()
    def view_bookings(self):
        self.view_bookings_screen = ViewBookings()
        self.view_bookings_screen.show()
    def available_flights(self):
        self.available_flights_screen = ViewAvailableFlights()
        self.available_flights_screen.show()

class ViewBookings(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('Screens/Travel Agent/View Bookings.ui', self)
        self.show_booked_flights()
        self.amountpaid_pushButton_2.clicked.connect(self.show_amount_paid)
        self.passinfo_pushButton.clicked.connect(self.show_passenger_info)

    def show_booked_flights(self):
        try:
            connection = pyodbc.connect(connection_string)
            cursor = connection.cursor()

            cursor.execute("""
                SELECT Bookings.Booking_id, Flights.Flight_id, Flights.Departure_city, Flights.Arrival_city
                FROM Bookings
                JOIN Flights ON Bookings.Flight_id = Flights.Flight_id
                WHERE Bookings.booking_status = 1
            """)

            booked_flights = cursor.fetchall()

            connection.close()

            self.populate_bookings_table(booked_flights)

        except pyodbc.Error as ex:
            print("Error fetching booked flights:", ex)

    def populate_bookings_table(self, booked_flights):
        self.bookings_tableWidget.clear()
        self.bookings_tableWidget.setRowCount(len(booked_flights))
        self.bookings_tableWidget.setColumnCount(len(booked_flights[0]))  # Set column count to the number of columns in the fetched data
        self.bookings_tableWidget.setHorizontalHeaderLabels(["Booking ID", "Flight ID", "DepCity", "ArrCity"])

        for row_index, row_data in enumerate(booked_flights):
            for col_index, col_data in enumerate(row_data):
                item = QtWidgets.QTableWidgetItem(str(col_data))
                self.bookings_tableWidget.setItem(row_index, col_index, item)

    def show_amount_paid(self):
        selected_row = self.bookings_tableWidget.currentRow()
        if selected_row >= 0:
            booking_id_item = self.bookings_tableWidget.item(selected_row, 0)
            if booking_id_item is not None:
                booking_id = booking_id_item.text()
                amount_paid = self.retrieve_amount_paid(booking_id)
                self.amount_lineEdit.setText(str(amount_paid))
            else:
                print("No booking ID found in the selected row.")
        else:
            print("No row is selected.")

    def retrieve_amount_paid(self, booking_id):
        try:
            connection = pyodbc.connect(connection_string)
            cursor = connection.cursor()

            cursor.execute("SELECT amount_paid FROM Bookings WHERE Booking_id = ?", (booking_id,))
            amount_paid = cursor.fetchone()[0]

            connection.close()
            return amount_paid

        except pyodbc.Error as ex:
            print("Error:", ex)

    def show_passenger_info(self):
        selected_row = self.bookings_tableWidget.currentRow()
        if selected_row >= 0:
            booking_id_item = self.bookings_tableWidget.item(selected_row, 0)
            if booking_id_item is not None:
                booking_id = booking_id_item.text()
                passenger_info = self.retrieve_passenger_info(booking_id)
                self.populate_passenger_table(passenger_info)
            else:
                print("No booking ID found in the selected row.")
        else:
            print("No row is selected.")

    def retrieve_passenger_info(self, booking_id):
        try:
            connection = pyodbc.connect(connection_string)
            cursor = connection.cursor()

            cursor.execute("""
                SELECT First_name, Last_name, Date_of_birth
                FROM PassengerInformation
                WHERE Booking_id = ?
            """, (booking_id,))

            passenger_info = cursor.fetchall()

            connection.close()
            return passenger_info

        except pyodbc.Error as ex:
            print("Error fetching passenger information:", ex)

    def populate_passenger_table(self, passenger_info):
        self.pass_tableWidget_2.clear()
        self.pass_tableWidget_2.setRowCount(len(passenger_info))
        self.pass_tableWidget_2.setColumnCount(len(passenger_info[0]))  # Set column count to the number of columns in the fetched data
        self.pass_tableWidget_2.setHorizontalHeaderLabels(["First Name", "Last Name", "Date of Birth"])

        for row_index, row_data in enumerate(passenger_info):
            for col_index, col_data in enumerate(row_data):
                item = QtWidgets.QTableWidgetItem(str(col_data))
                self.pass_tableWidget_2.setItem(row_index, col_index, item)

class AddFlightsDialog(QtWidgets.QMainWindow):
    def __init__(self):
        super(AddFlightsDialog, self).__init__()
        uic.loadUi('Screens/Travel Agent/Add Flights.ui', self)
        self.AddFlight_pushButton.clicked.connect(self.add_flight)
        self.populate_facilities()

        self.selected_facilities = []
        self.AddFacility_pushButton.clicked.connect(self.add_facility)

        self.populate_airlines()
    
    def populate_airlines(self):
        try:
            connection = pyodbc.connect(connection_string)
            cursor = connection.cursor()

            cursor.execute("SELECT Name FROM Airlines")  # Fetch airline names
            airlines = cursor.fetchall()

            for airline in airlines:
                self.Airline_comboBox.addItem(airline[0])  # Add airline names to the combobox

            connection.close()

        except pyodbc.Error as ex:
            print("Error:", ex)
    def populate_facilities(self):
        try:
            connection = pyodbc.connect(connection_string)
            cursor = connection.cursor()

            cursor.execute("SELECT Name FROM Facilities")
            facilities = cursor.fetchall()

            for facility in facilities:
                self.FacilitieslistWidget.addItem(facility[0])

            connection.close()

        except pyodbc.Error as ex:
            print("Error:", ex)

    def add_facility(self):
        selected_facility = self.FacilitieslistWidget.currentItem().text()
        self.selected_facilities.append(selected_facility)

    def add_flight(self):
        airline = self.Airline_comboBox.currentText() 
        departure_city = self.DepartureCity_lineEdit.text()
        arrival_city = self.ArrivalCity_lineEdit.text()
        departure_time = self.DepartureTime_lineEdit.text()
        arrival_time = self.ArrivalTime_lineEdit.text()
        seats = self.seats_lineEdit.text()
        cost = self.cost_lineEdit.text()
        departure_airport = self.DeaprtureAirport_lineEdit.text()
        arrival_airport = self.ArrivalAirport_lineEdit.text()
        departure_date = self.DepartureDate_lineEdit.text()
        arrival_date = self.ArrivalDate_lineEdit.text()

        # Check if any field is empty
        if (not airline or not departure_city or not arrival_city or not departure_time or not arrival_time or
            not seats or not cost or not departure_airport or not arrival_airport or not departure_date or not arrival_date):
            QtWidgets.QMessageBox.warning(self, "Incomplete Information", "Please fill in all fields.")
            return

        connection = pyodbc.connect(connection_string)
        cursor = connection.cursor()

        try:
            cursor.execute("SELECT Airline_id FROM Airlines WHERE Name = ?", (airline,))
            airline_id = cursor.fetchone()[0]

            cursor.execute("SELECT @@IDENTITY AS 'Flight_id'")
            flight_id = cursor.fetchone()[0]

            self.current_flight_id = flight_id
            
            cursor.execute("""
                INSERT INTO Flights 
                (Airline_id, Departure_city, Arrival_city, Departure_time, Arrival_time, Seats, available_seats, Cost, Departure_airport, Arrival_airport, Departure_date, Arrival_date) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (airline_id, departure_city, arrival_city, departure_time, arrival_time, seats, seats, cost, departure_airport, arrival_airport, departure_date, arrival_date))
            connection.commit()

            cursor.execute("SELECT @@IDENTITY AS 'Flight_id'")
            flight_id = cursor.fetchone()[0]

            for index in range(self.FacilitieslistWidget.count()):
                facility_item = self.FacilitieslistWidget.item(index)
                if facility_item.isSelected():
                    facility = facility_item.text()
                    cursor.execute("SELECT Facility_id FROM Facilities WHERE Name = ?", (facility,))
                    facility_id = cursor.fetchone()[0]
                    cursor.execute("INSERT INTO FlightFacilities (Flight_id, Facility_id) VALUES (?, ?)", (flight_id, facility_id))
                    connection.commit()

            connection.close()
            self.clear_fields()
            self.show_success_message()
            self.close()

        except pyodbc.Error as ex:
            print("Error:", ex)

    def clear_fields(self):
        self.Airline_comboBox.setCurrentIndex(-1)
        self.DepartureCity_lineEdit.clear()
        self.ArrivalCity_lineEdit.clear()
        self.DepartureTime_lineEdit.clear()
        self.ArrivalTime_lineEdit.clear()
        self.seats_lineEdit.clear()
        self.cost_lineEdit.clear()
        self.DeaprtureAirport_lineEdit.clear()
        self.ArrivalAirport_lineEdit.clear()
        self.DepartureDate_lineEdit.clear()
        self.ArrivalDate_lineEdit.clear()
        self.FacilitieslistWidget.clear()

    def show_success_message(self):
        QtWidgets.QMessageBox.information(self, "Flight Added Successfully", "Your flight has been added successfully.")
        # uic.loadUi('Screens/Travel Agent/On Boarding.ui', self)


class PassengerInfoDialog(QtWidgets.QDialog):
    def __init__(self, num_passengers, flight_id, traveler_id, booking_id):
        super(PassengerInfoDialog, self).__init__()
        self.setFixedSize(1000, 600)
        self.num_passengers = num_passengers
        self.flight_id = flight_id
        self.traveler_id = traveler_id
        self.booking_id = booking_id
        self.passenger_info = []

        layout = QtWidgets.QVBoxLayout()

        scroll_area = QtWidgets.QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_content = QtWidgets.QWidget()
        scroll_layout = QtWidgets.QVBoxLayout(scroll_content)

        for i in range(num_passengers):
            name_label = QtWidgets.QLabel(f"Passenger {i + 1} First Name:")
            scroll_layout.addWidget(name_label)
            name_line_edit = QtWidgets.QLineEdit()
            name_line_edit.setFixedWidth(200)
            name_line_edit.setFixedHeight(25)
            scroll_layout.addWidget(name_line_edit)
            name_line_edit.textChanged.connect(lambda text, index=i: self.update_passenger_info(text, index, 'FirstName'))

            email_label = QtWidgets.QLabel(f"Passenger {i + 1} Last Name:")
            scroll_layout.addWidget(email_label)
            email_line_edit = QtWidgets.QLineEdit()
            email_line_edit.setFixedWidth(200)
            email_line_edit.setFixedHeight(25)
            scroll_layout.addWidget(email_line_edit)
            email_line_edit.textChanged.connect(lambda text, index=i: self.update_passenger_info(text, index, 'LastName'))

            dob_label = QtWidgets.QLabel(f"Passenger {i + 1} Date of Birth:")
            scroll_layout.addWidget(dob_label)
            dob_edit = QtWidgets.QDateEdit()
            dob_edit.setFixedWidth(200)
            dob_edit.setFixedHeight(25)
            dob_edit.setDisplayFormat("yyyy-MM-dd")
            scroll_layout.addWidget(dob_edit)
            dob_edit.dateChanged.connect(lambda date, index=i: self.update_passenger_info(date.toString("yyyy-MM-dd"), index, 'dob'))

        scroll_content.setLayout(scroll_layout)
        scroll_area.setWidget(scroll_content)
        layout.addWidget(scroll_area)

        self.submit_button = QPushButton("Submit")
        self.submit_button.setFixedSize(100, 30)
        self.submit_button.setStyleSheet(
            "background-color: rgb(208, 222, 231);"
            "font: 10pt 'Comic Sans MS';"
            "font-weight: bold;"
            "color: #00007f;"
            "border-style: outset;"
            "border-width: 1px;"
            "border-radius: 10px;"
            "border-color: #597489f;"
        )
        layout.addWidget(self.submit_button, alignment=Qt.AlignmentFlag.AlignCenter) 

        self.setStyleSheet(
            "color: #00007f;"
            "font: 10pt 'Comic Sans MS';"
            "font-weight: bold;"
            "background-color: #ebf5fe;"
        )

        self.apply_style_to_textboxes(scroll_layout)

        self.setLayout(layout)

    def apply_style_to_textboxes(self, layout):
        for i in range(layout.count()):
            item = layout.itemAt(i)
            if isinstance(item, QLabel):
                item.widget().setStyleSheet(
                    "color: #00007f;"
                    "font: 10pt 'Comic Sans MS';"
                    "font-weight: bold;"
                )
            elif isinstance(item, QLineEdit) or isinstance(item, QDateEdit):
                widget = item.widget()
                widget.setStyleSheet(
                    "QLineEdit, QDateEdit { background-color: #ffffff; }"  
                )
                widget.setAutoFillBackground(True)  
                palette = widget.palette()
                palette.setColor(widget.backgroundRole(), Qt.GlobalColor.white)
                widget.setPalette(palette)
        # self.setLayout(layout)
        self.worker = None 
        self.payment_dialog = None  

        self.submit_button.clicked.connect(self.save_passenger_info)
    def update_passenger_info(self, text, index, field):
        while len(self.passenger_info) <= index:
            self.passenger_info.append({'FirstName': '', 'LastName': '', 'dob': ''})
        self.passenger_info[index][field] = text

    def handle_save_passenger_info_result(self):
        QtWidgets.QMessageBox.information(self, "Passenger Information Saved", "Passenger details have been saved.")
        self.next_screen_payment()

    def next_screen_payment(self):
        self.close()  # Close the current dialog
        self.payment_dialog = Payment(self.traveler_id, self.flight_id, self.booking_id)
        self.payment_dialog.show()

    def save_passenger_info(self):
        self.worker = SavePassengerInfoThread(self.passenger_info, self.booking_id)
        self.worker.finished.connect(self.handle_save_passenger_info_result)
        self.worker.start()
        self.close()
        

class SavePassengerInfoThread(QtCore.QThread):
    finished = QtCore.pyqtSignal()

    def __init__(self, passenger_info, booking_id):
        super().__init__()
        self.passenger_info = passenger_info
        self.booking_id = booking_id
        

    def run(self):
        try:
            connection = pyodbc.connect(connection_string)
            cursor = connection.cursor()

            for passenger in self.passenger_info:
                cursor.execute("""
                    INSERT INTO PassengerInformation (First_name, Last_name, Date_of_birth, Booking_id)
                    VALUES (?, ?, ?, ?)
                """, (passenger['FirstName'], passenger['LastName'], passenger['dob'], self.booking_id))
                connection.commit()

            connection.close()
            self.finished.emit()  # Signal the completion of the database operations

        except pyodbc.Error as ex:
            print("Error:", ex)

class Payment(QtWidgets.QMainWindow):
    def __init__(self, traveler_id, flight_id, booking_id):
        super(Payment, self).__init__()
        uic.loadUi('Screens/Travelor/Payment Portal.ui', self)
        self.proceedtopay.clicked.connect(self.proceed_to_pay)

        self.flight_id = flight_id
        self.booking_id = booking_id
        self.traveler_id = traveler_id
        self.populate_flight_details()

    def populate_flight_details(self):
        try:
            connection = pyodbc.connect(connection_string)
            cursor = connection.cursor()

            cursor.execute("""
                SELECT Airlines.Name, Flights.Departure_city, Flights.Departure_time, Flights.Departure_airport,
                Flights.Arrival_city, Flights.Arrival_time, Flights.Arrival_airport, Facilities.Name, Flights.Cost
                FROM Flights
                JOIN Airlines ON Flights.Airline_id = Airlines.Airline_id
                JOIN FlightFacilities ON Flights.Flight_id = FlightFacilities.Flight_id
                JOIN Facilities ON FlightFacilities.Facility_id = Facilities.Facility_id
                WHERE Flights.Flight_id = ?
            """, (self.flight_id,))
            
            flight_details = cursor.fetchall()
            if flight_details:
                airline_name = flight_details[0][0]
                departure_city = flight_details[0][1]
                departure_time = flight_details[0][2]
                departure_airport = flight_details[0][3]
                arrival_city = flight_details[0][4]
                arrival_time = flight_details[0][5]
                arrival_airport = flight_details[0][6]
                facilities = ', '.join([row[7] for row in flight_details])
                cost = flight_details[0][8]

                self.airline_line_edit.setText(airline_name)
                self.depcity_lineedit.setText(departure_city)
                self.deptime_lineedit.setText(str(departure_time))
                self.depairport_lineedit.setText(departure_airport)
                self.arrcity_lineedit.setText(arrival_city)
                self.arrtime_lineedit.setText(str(arrival_time))
                self.arrairport_lineedit.setText(arrival_airport)
                self.fac_lineedit.setText(facilities)
                self.cost_lineedit.setText(str(cost))

                num_passengers = self.get_passenger_count()
                self.total_cost = cost * num_passengers
                self.whatupay_lineedit.setText(str(self.total_cost))

            connection.close()

        except pyodbc.Error as ex:
            print("Error:", ex)

    def get_passenger_count(self):
        try:
            connection = pyodbc.connect(connection_string)
            cursor = connection.cursor()

            cursor.execute("SELECT COUNT(*) FROM PassengerInformation WHERE Booking_id = ?", (self.booking_id,))
            count = cursor.fetchone()[0]

            connection.close()
            return count

        except pyodbc.Error as ex:
            print("Error:", ex)
            return 0

    def proceed_to_pay(self):
        self.hide()
        self.CardDetailsWindow = CardDetails(self, self.traveler_id, self.flight_id, self.booking_id, self.total_cost)
        self.close()
        self.CardDetailsWindow.show()


class CardDetails(QtWidgets.QMainWindow):
    def __init__(self, payment_screen, traveler_id, flight_id, booking_id, total_cost):
        super(CardDetails, self).__init__()
        uic.loadUi('Screens/Travelor/Card Details.ui', self)

        self.payment_screen = payment_screen
        self.flight_id = flight_id
        self.booking_id = booking_id
        self.total_cost = total_cost
        self.traveler_id = traveler_id

        self.final_booking.clicked.connect(self.confirm_payment)

    def confirm_payment(self):
        cvv = self.cvv_lineEdit.text()
        streetAddress = self.sa_lineedit.text()
        cvvCode = self.code_lineEdit.text()
        country = self.c_lineedit.text()
        city = self.city_lineedit.text()

        if not all([cvv, streetAddress, cvvCode, city]):
            QtWidgets.QMessageBox.warning(self, "Incomplete Information", "Please fill in all required fields.")
            return

        connection = pyodbc.connect(connection_string)
        cursor = connection.cursor()

        try:
            cursor.execute("UPDATE Bookings SET booking_status = ?, amount_paid = ? WHERE Booking_id = ?", ('true', self.total_cost, self.booking_id))
            connection.commit()
            cursor.execute("SELECT COUNT(*) FROM PassengerInformation WHERE Booking_id = ?", (self.booking_id,))
            count = cursor.fetchone()[0]
            cursor.execute("SELECT available_seats FROM Flights WHERE Flight_id = ?", (self.flight_id,))
            total_seats = cursor.fetchone()[0]
            available_seats = max(total_seats - count, 0)
            cursor.execute("UPDATE Flights SET available_seats = ? WHERE Flight_id = ?", (available_seats, self.flight_id))
            connection.commit()
            connection.close()
            QtWidgets.QMessageBox.information(self, "Payment Successful", "Your payment has been processed, and the flight has been booked.")
            self.show_search_flights_screen()  

        except pyodbc.Error as ex:
            print("Error:", ex)
            QtWidgets.QMessageBox.critical(self, "Error", "Failed to update booking status.")

    def show_search_flights_screen(self):
        self.close()  # Close the current window
        self.search_flights = SearchFlights(self.traveler_id)  # Replace 'traveler_id' with the appropriate traveler ID
        self.search_flights.show()

class ViewAvailableFlights(QtWidgets.QMainWindow):
    def __init__(self):
        super(ViewAvailableFlights, self).__init__()
        uic.loadUi('Screens/Travel Agent/Available Flights.ui', self)
        self.edit_flight_dialog = None 
        self.AvailableFlightsTableWidget.setColumnCount(12)  # Assuming there are 12 columns in the table
        self.headers = ["FlightID", "AirlineID", "DepartureCity", "ArrivalCity", "DepartureTime", "ArrivalTime", "AvailableSeats", "Seats", "Cost", "DepAirport", "ArrivalAirport", "DepartureDate", "ArrivalDate"]
        self.AvailableFlightsTableWidget.setHorizontalHeaderLabels(self.headers)

        self.populate_available_flights()

        self.DeleteButton.clicked.connect(self.delete_flight)
        self.EditButton.clicked.connect(self.edit_flight)
        # self.edit_flight_dialog.flight_updated.connect(self.populate_available_flights)

    def populate_available_flights(self):
        try:
            print("Im calling this function")
            self.AvailableFlightsTableWidget.clear()
            self.AvailableFlightsTableWidget.setHorizontalHeaderLabels(self.headers)
            connection = pyodbc.connect(connection_string)
            cursor = connection.cursor()

            cursor.execute("""
                SELECT Flight_id, Airline_id, Departure_city, Arrival_city, Departure_time, Arrival_time, available_seats, Seats, Cost, Departure_airport, Arrival_airport, Departure_date, Arrival_date
                FROM Flights 
                WHERE available_seats > 0
            """)
            flights = cursor.fetchall()

            if flights:
                self.AvailableFlightsTableWidget.setRowCount(len(flights))

                for row_num, row_data in enumerate(flights):
                    for col_num, data in enumerate(row_data):
                        item = QtWidgets.QTableWidgetItem(str(data))
                        self.AvailableFlightsTableWidget.setItem(row_num, col_num, item)

            connection.close()

        except pyodbc.Error as ex:
            print("Error fetching available flights:", ex)

    def delete_flight(self):
        selected_row = self.AvailableFlightsTableWidget.currentRow()
        if selected_row != -1:
            flight_id_item = self.AvailableFlightsTableWidget.item(selected_row, 0)
            if flight_id_item:
                flight_id = int(flight_id_item.text())

                try:
                    connection = pyodbc.connect(connection_string)
                    cursor = connection.cursor()
                    cursor.execute("DELETE FROM FlightFacilities WHERE Flight_id = ?", (flight_id,))
                    cursor.execute("DELETE FROM Flights WHERE Flight_id = ?", (flight_id,))
                    connection.commit()

                    self.populate_available_flights()  # Update the table widget after deletion

                    connection.close()

                except pyodbc.Error as ex:
                    print("Error deleting flight:", ex)
        else:
            QtWidgets.QMessageBox.warning(self, "No Flight Selected", "Please select a flight to delete.")

    def edit_flight(self):
        selected_row = self.AvailableFlightsTableWidget.currentRow()
        if selected_row != -1:
            flight_id_item = self.AvailableFlightsTableWidget.item(selected_row, 0)
            if flight_id_item:
                flight_id = int(flight_id_item.text())
                self.edit_flight_dialog = EditFlightDialog(flight_id)
                self.edit_flight_dialog.flight_updated.connect(self.populate_available_flights)  # Connect signal
                self.edit_flight_dialog.show()
            else:
                QtWidgets.QMessageBox.warning(self, "Error", "No Flight ID found in the selected row.")
        else:
            QtWidgets.QMessageBox.warning(self, "Error", "Please select a flight to edit.")


class EditFlightDialog(QtWidgets.QMainWindow):
    flight_updated = QtCore.pyqtSignal()
    def __init__(self, flight_id):
        super(EditFlightDialog, self).__init__()
        uic.loadUi('Screens/Travel Agent/Edit Flights.ui', self)
        self.flight_id = flight_id

        self.populate_facilities()
        self.populate_airlines()
        self.load_flight_data()
        # self.EditFlight_pushButton.clicked.connect(self.connect_signals)

        self.EditFlight_pushButton.clicked.connect(self.update_database)
        # flight_updated = QtCore.pyqtSignal()

    def update_database(self):
        try:
            self.update_departure_date()
            self.update_arrival_date()
            self.update_departure_airport()
            self.update_seats_available()
            self.update_arrival_airport()
            self.update_arrival_city()
            self.update_departure_city()
            self.update_arrival_time()
            self.update_departure_time()
            self.update_cost()
            self.update_seats()
            self.update_facilities()
            QtWidgets.QMessageBox.information(self, "Success", "Flight updated successfully.")
            self.flight_updated.emit()
            self.close()

        except pyodbc.Error as ex:
            print("Error updating flight:", ex)

    def update_departure_date(self):
        new_departure_date = self.DepartureDate_lineEdit.text()
        if new_departure_date:
            try:
                connection = pyodbc.connect(connection_string)
                cursor = connection.cursor()

                cursor.execute("""
                    UPDATE Flights
                    SET departure_date = ?
                    WHERE flight_id = ?
                """, (new_departure_date, self.flight_id))
                connection.commit()

                connection.close()

            except pyodbc.Error as ex:
                print("Error updating departure date:", ex)

    def update_arrival_date(self):
        new_arrival_date = self.ArrivalDate_lineEdit.text()
        if new_arrival_date:
            try:
                connection = pyodbc.connect(connection_string)
                cursor = connection.cursor()

                cursor.execute("""
                    UPDATE Flights
                    SET arrival_date = ?
                    WHERE flight_id = ?
                """, (new_arrival_date, self.flight_id))
                connection.commit()

                connection.close()

            except pyodbc.Error as ex:
                print("Error updating arrival date:", ex)

    def update_departure_airport(self):
        new_departure_airport = self.DeaprtureAirport_lineEdit.text()

        try:
            connection = pyodbc.connect(connection_string)
            cursor = connection.cursor()

            cursor.execute("""
                UPDATE Flights
                SET departure_airport = ?
                WHERE flight_id = ?
            """, (new_departure_airport, self.flight_id))
            
            connection.commit()
            connection.close()
        except pyodbc.Error as ex:
            print("Error updating departure airport:", ex)

    def update_arrival_airport(self):
        new_arrival_airport = self.ArrivalAirport_lineEdit.text()

        try:
            connection = pyodbc.connect(connection_string)
            cursor = connection.cursor()

            cursor.execute("""
                UPDATE Flights
                SET arrival_airport = ?
                WHERE flight_id = ?
            """, (new_arrival_airport, self.flight_id))
            
            connection.commit()
            connection.close()

        except pyodbc.Error as ex:
            print("Error updating arrival airport:", ex)

    def update_facilities(self):
        try:
            selected_facilities = [self.FacilitieslistWidget.item(index).text() for index in range(self.FacilitieslistWidget.count()) if self.FacilitieslistWidget.item(index).isSelected()]

            connection = pyodbc.connect(connection_string)
            cursor = connection.cursor()

            cursor.execute("DELETE FROM FlightFacilities WHERE Flight_id = ?", (self.flight_id,))

            for facility in selected_facilities:
                cursor.execute("SELECT Facility_id FROM Facilities WHERE Name = ?", (facility,))
                facility_id = cursor.fetchone()[0]
                cursor.execute("INSERT INTO FlightFacilities (Flight_id, Facility_id) VALUES (?, ?)", (self.flight_id, facility_id))

            connection.commit()
            connection.close()

        except pyodbc.Error as ex:
            print("Error updating facilities:", ex)

    def update_arrival_time(self):
        try:
            new_arrival_time = self.ArrivalTime_lineEdit.text()

            # Assuming the arrival_time column type in the database is a TIME type
            connection = pyodbc.connect(connection_string)
            cursor = connection.cursor()

            cursor.execute("UPDATE Flights SET arrival_time = ? WHERE flight_id = ?", (new_arrival_time, self.flight_id))
            connection.commit()

            connection.close()

        except pyodbc.Error as ex:
            print("Error updating arrival time:", ex)

    def update_departure_time(self):
        try:
            new_departure_time = self.DepartureTime_lineEdit.text()

            # Assuming the departure_time column type in the database is a TIME type
            connection = pyodbc.connect(connection_string)
            cursor = connection.cursor()

            cursor.execute("UPDATE Flights SET departure_time = ? WHERE flight_id = ?", (new_departure_time, self.flight_id))
            connection.commit()

            connection.close()

        except pyodbc.Error as ex:
            print("Error updating departure time:", ex)

    def update_seats_available(self):
        try:
            new_seats = self.a_seats_lineEdit_2.text()

            connection = pyodbc.connect(connection_string)
            cursor = connection.cursor()

            cursor.execute("UPDATE Flights SET available_seats = ? WHERE flight_id = ?", (new_seats, self.flight_id))
            connection.commit()

            connection.close()

        except (pyodbc.Error, ValueError) as ex:
            print("Error updating seats:", ex)
    
    def update_seats(self):
        try:
            new_seats = self.seats_lineEdit.text()

            connection = pyodbc.connect(connection_string)
            cursor = connection.cursor()

            cursor.execute("UPDATE Flights SET Seats = ? WHERE flight_id = ?", (new_seats, self.flight_id))
            connection.commit()

            connection.close()

        except (pyodbc.Error, ValueError) as ex:
            print("Error updating seats:", ex)

    def update_cost(self):
        try:
            new_cost = float(self.cost_lineEdit.text())

            connection = pyodbc.connect(connection_string)
            cursor = connection.cursor()

            cursor.execute("UPDATE Flights SET cost = ? WHERE flight_id = ?", (new_cost, self.flight_id))
            connection.commit()

            connection.close()

        except (pyodbc.Error, ValueError) as ex:
            print("Error updating cost:", ex)

    def update_airline(self):
        try:
            new_airline_name = self.Airline_comboBox.currentText()

            connection = pyodbc.connect(connection_string)
            cursor = connection.cursor()

            cursor.execute("SELECT Airline_id FROM Airlines WHERE Name = ?", (new_airline_name,))
            airline_id = cursor.fetchone()[0]

            cursor.execute("UPDATE Flights SET airline_id = ? WHERE flight_id = ?", (airline_id, self.flight_id))
            connection.commit()

            connection.close()

        except pyodbc.Error as ex:
            print("Error updating airline:", ex)

    def update_departure_city(self):
        try:
            new_departure_city = self.DepartureCity_lineEdit.text()

            connection = pyodbc.connect(connection_string)
            cursor = connection.cursor()

            cursor.execute("UPDATE Flights SET departure_city = ? WHERE flight_id = ?", (new_departure_city, self.flight_id))
            connection.commit()

            connection.close()

        except pyodbc.Error as ex:
            print("Error updating departure city:", ex)

    def update_arrival_city(self):
        try:
            new_arrival_city = self.ArrivalCity_lineEdit.text()

            connection = pyodbc.connect(connection_string)
            cursor = connection.cursor()

            cursor.execute("UPDATE Flights SET arrival_city = ? WHERE flight_id = ?", (new_arrival_city, self.flight_id))
            connection.commit()

            connection.close()

        except pyodbc.Error as ex:
            print("Error updating arrival city:", ex)
    def populate_facilities(self):
        try:
            connection = pyodbc.connect(connection_string)
            cursor = connection.cursor()

            cursor.execute("SELECT Name FROM Facilities")
            facilities = cursor.fetchall()

            for facility in facilities:
                self.FacilitieslistWidget.addItem(facility[0])

            connection.close()

        except pyodbc.Error as ex:
            print("Error:", ex)

    def populate_airlines(self):
        try:
            connection = pyodbc.connect(connection_string)
            cursor = connection.cursor()

            cursor.execute("SELECT Name FROM Airlines")  # Fetch airline names
            airlines = cursor.fetchall()

            for airline in airlines:
                self.Airline_comboBox.addItem(airline[0])  # Add airline names to the combobox

            connection.close()

        except pyodbc.Error as ex:
            print("Error:", ex)

    def load_flight_data(self):
        try:
            connection = pyodbc.connect(connection_string)
            cursor = connection.cursor()

            cursor.execute("""
                SELECT flight_id, airline_id, departure_city, arrival_city, departure_time, arrival_time, available_seats, seats, cost,
                       departure_airport, arrival_airport, departure_date, arrival_date
                FROM Flights
                WHERE flight_id = ?
            """, (self.flight_id,))
            flight_data = cursor.fetchone()

            if flight_data:
                self.flight_id, airline_id, departure_city, arrival_city, departure_time, arrival_time, available_seats, seats, cost, departure_airport, arrival_airport, departure_date, arrival_date = flight_data

                cursor.execute("""
                    SELECT Facilities.Name
                    FROM Facilities
                    INNER JOIN FlightFacilities ON Facilities.Facility_id = FlightFacilities.Facility_id
                    WHERE FlightFacilities.Flight_id = ?
                """, (self.flight_id,))
                facilities = cursor.fetchall()
                selected_facilities = [facility[0] for facility in facilities]

                # Fetch the airline name based on airline_id
                cursor.execute("SELECT Name FROM Airlines WHERE Airline_id = ?", (airline_id,))
                airline_name = cursor.fetchone()[0]
                self.Airline_comboBox.setCurrentText(airline_name)  # Set the airline combo box text

                self.DepartureCity_lineEdit.setText(departure_city)
                self.ArrivalCity_lineEdit.setText(arrival_city)
                self.DepartureTime_lineEdit.setText(departure_time.strftime('%H:%M'))
                self.ArrivalTime_lineEdit.setText(arrival_time.strftime('%H:%M'))
                self.seats_lineEdit.setText(str(seats))
                self.a_seats_lineEdit_2.setText(str(available_seats))
                self.cost_lineEdit.setText(str(cost))
                self.DeaprtureAirport_lineEdit.setText(departure_airport)
                self.ArrivalAirport_lineEdit.setText(arrival_airport)
                self.DepartureDate_lineEdit.setText(departure_date.strftime('%Y-%m-%d'))
                self.ArrivalDate_lineEdit.setText(arrival_date.strftime('%Y-%m-%d'))

                for index in range(self.FacilitieslistWidget.count()):
                    facility_item = self.FacilitieslistWidget.item(index)
                    facility_text = facility_item.text()
                    if facility_text.strip() in selected_facilities:
                        facility_item.setSelected(True)

            connection.close()

        except pyodbc.Error as ex:
            print("Error fetching flight details:", ex)

def main():
    app = QtWidgets.QApplication(sys.argv)
    window = OnBoarding()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()