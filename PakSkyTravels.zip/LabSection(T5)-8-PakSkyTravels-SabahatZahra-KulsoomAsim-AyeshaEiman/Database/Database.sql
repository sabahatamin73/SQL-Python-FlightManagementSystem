-- Creating Airlines table
CREATE TABLE Airlines (
    Airline_id INT PRIMARY KEY IDENTITY(1,1) ,
    Name VARCHAR(100)
);

-- Creating Facilities table
CREATE TABLE Facilities (
    Facility_id INT PRIMARY KEY IDENTITY(1,1),
    Name VARCHAR(100)
);

-- Creating Flights table
CREATE TABLE Flights (
    Flight_id INT PRIMARY KEY IDENTITY(1,1),
    Departure_city VARCHAR(100),
    Arrival_city VARCHAR(100),
    Departure_time TIME,
    Arrival_time TIME,
    Departure_date DATE,
    Arrival_date DATE,
    Departure_airport VARCHAR(100),
    Arrival_airport VARCHAR(100),
    Cost DECIMAL(10, 2),
    Seats INT,
    available_seats INT,
    Airline_id INT,
    FOREIGN KEY (Airline_id) REFERENCES Airlines(Airline_id)
);

-- Creating FlightFacilities table (many-to-many relationship between Flights and Facilities)
CREATE TABLE FlightFacilities (
    Flight_id INT,
    Facility_id INT,
    FOREIGN KEY (Flight_id) REFERENCES Flights(Flight_id),
    FOREIGN KEY (Facility_id) REFERENCES Facilities(Facility_id),
    PRIMARY KEY (Flight_id, Facility_id)
);

-- Creating TravelAgent table
CREATE TABLE TravelAgent (
    TravelAgent_id INT PRIMARY KEY IDENTITY(1,1),
    Username VARCHAR(50),
    Password VARCHAR(50)
);


-- Creating Travelor table
CREATE TABLE Travelor (
    Travelor_id INT PRIMARY KEY IDENTITY(1,1),
    Name VARCHAR(100),
    Email VARCHAR(100),
    Username VARCHAR(50),
    Password VARCHAR(50)
);

-- Creating Bookings table
CREATE TABLE Bookings (
    Booking_id INT PRIMARY KEY IDENTITY(1,1),
    Flight_id INT,
    Travelor_id INT,
    booking_status VARCHAR(50),
    amount_paid DECIMAL(10, 2) DEFAULT 0.00,
    FOREIGN KEY (Flight_id) REFERENCES Flights(Flight_id),
    FOREIGN KEY (Travelor_id) REFERENCES Travelor(Travelor_id)
);

-- Creating PassengerInformation table
CREATE TABLE PassengerInformation (
    Passenger_id INT PRIMARY KEY IDENTITY(1,1),
    First_name VARCHAR(50),
    Last_name VARCHAR(50),
    Date_of_birth DATE,
    Booking_id INT,
    FOREIGN KEY (Booking_id) REFERENCES Bookings(Booking_id)
);


-- By default add values for airlines
INSERT INTO Airlines (Name)
VALUES ('Delta Airlines'),
       ('American Airlines'),
       ('United Airlines'),
       ('Southwest Airlines'),
       ('Lufthansa'),
       ('British Airways');

-- Bye default credentials for travel agent
INSERT INTO TravelAgent (Username, password)
VALUES ('test', '123');